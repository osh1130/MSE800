document.getElementById('alertBtn').addEventListener('click', function() {
    alert('Hello from JavaScript!');
});
